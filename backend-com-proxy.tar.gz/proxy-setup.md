# 🛡️ Configurar Proxy para Pagar.me (Mascarar IP)

## Opção 1: ngrok (RECOMENDADO - Mais Fácil)

### Passo 1: Instalar ngrok
```bash
# No Mac
brew install ngrok

# Ou baixe em: https://ngrok.com/download
```

### Passo 2: Rodar o backend
```bash
cd ~/Documents/afterpay-mvp/backend
npm run dev
```

### Passo 3: Criar túnel
Em outro terminal:
```bash
ngrok http 3001
```

### Passo 4: Ver o IP do ngrok
O ngrok vai mostrar algo como:
```
Forwarding: https://abc123.ngrok.io -> http://localhost:3001
```

Acesse: https://dashboard.ngrok.com/ → Agent → Online
Copie o IP que aparece (ex: `52.23.45.67`)

### Passo 5: Autorizar IP na Pagar.me
1. Dashboard Pagar.me → Configurações → Segurança
2. Adicione o IP do ngrok
3. Salve

### Passo 6: Atualizar frontend
No código do frontend, troque:
```javascript
http://localhost:3001
```
Por:
```javascript
https://abc123.ngrok.io
```

---

## Opção 2: Proxy HTTP (Avançado)

### Passo 1: Instalar biblioteca de proxy
```bash
cd ~/Documents/afterpay-mvp/backend
npm install https-proxy-agent
```

### Passo 2: Adicionar proxy no .env
```bash
# Adicione no arquivo .env:
HTTP_PROXY=http://proxy-servidor.com:8080
# Ou use um proxy gratuito como:
# HTTP_PROXY=http://20.81.62.32:3128
```

### Passo 3: O código já vai usar automaticamente!

---

## Opção 3: Deploy em servidor gratuito

### Railway (recomendado)
1. Acesse: https://railway.app/
2. Conecte seu GitHub
3. Deploy o backend
4. Copie o IP do servidor Railway
5. Autorize na Pagar.me

### Render
1. Acesse: https://render.com/
2. Crie Web Service
3. Deploy o backend
4. Copie o IP
5. Autorize na Pagar.me

---

## 🎯 Qual escolher?

| Opção | Facilidade | Velocidade | Custo |
|-------|-----------|-----------|-------|
| **ngrok** | ⭐⭐⭐⭐⭐ | Rápido | Grátis |
| **Proxy HTTP** | ⭐⭐⭐ | Médio | Grátis |
| **Deploy servidor** | ⭐⭐ | Lento | Grátis |

**Recomendo: ngrok** → Mais rápido de configurar!
